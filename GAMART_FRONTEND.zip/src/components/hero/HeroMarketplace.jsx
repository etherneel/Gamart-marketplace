import React from 'react';

function HeroMarketplace() {
  return (
    <div>
      <div>
        <div className="hero_marketplace bg_white">
          <div className="container">
            <h1 className="text-center">NFT Marketplace</h1>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HeroMarketplace;
